package com.web2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Web2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
